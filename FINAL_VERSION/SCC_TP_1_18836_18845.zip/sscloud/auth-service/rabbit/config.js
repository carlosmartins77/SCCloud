module.exports = {
  rabbitMQ: {
    url: "amqp://localhost",
    exchangeName: "logExchange",
  },
};
